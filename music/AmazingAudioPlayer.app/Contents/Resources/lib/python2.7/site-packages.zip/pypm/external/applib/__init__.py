# Copyright (c) 2010 ActiveState Software Inc. All rights reserved.

__version_info__ = ('1', '2')
__version__ = '.'.join(__version_info__) + '.dev'
